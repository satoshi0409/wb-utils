import os
from setuptools import setup, find_packages

setup(
    name='scheduled_bots',
    packages=find_packages(),
)
